class Constants {
  static const String baseUrl = "https://localhost:7177/api";
  // For Android emulator use: http://10.0.2.2:5000/api
}
