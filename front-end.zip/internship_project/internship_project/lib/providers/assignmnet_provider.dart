import 'package:flutter/material.dart';
import '../models/internship_assignment.dart';
import '../services/assignment_service.dart';

class AssignmentProvider with ChangeNotifier {
  final AssignmentService _service = AssignmentService();

  List<InternshipAssignment> assignments = [];
  bool loading = false;

  Future<void> fetchAssignments() async {
    loading = true;
    notifyListeners();

    assignments = await _service.getAssignments();

    loading = false;
    notifyListeners();
  }

  Future<bool> assign(int applicationId, int mentorId) async {
    final ok = await _service.assign(applicationId, mentorId);
    if (ok) fetchAssignments();
    return ok;
  }
}
