import 'package:flutter/material.dart';
import '../models/mentor.dart';
import '../services/mentor_service.dart';

class MentorProvider with ChangeNotifier {
  final MentorService _service = MentorService();

  List<Mentor> mentors = [];
  bool loading = false;

  Future<void> fetchMentors() async {
    loading = true;
    notifyListeners();

    mentors = await _service.getMentors();

    loading = false;
    notifyListeners();
  }

  Future<bool> addMentor(String name, String email) async {
    final ok = await _service.createMentor(name, email);
    if (ok) fetchMentors();
    return ok;
  }

  Future<bool> removeMentor(int id) async {
    final ok = await _service.deleteMentor(id);
    if (ok) fetchMentors();
    return ok;
  }
}
