import 'package:flutter/material.dart';
import '../services/role_service.dart';
import '../models/internship_role.dart';

class RoleProvider extends ChangeNotifier {
  final RoleService _service = RoleService();

  List<InternshipRole> roles = [];
  bool isLoading = false;

  Future<void> fetchRoles() async {
    isLoading = true;
    notifyListeners();

    roles = await _service.getRoles();

    isLoading = false;
    notifyListeners();
  }
}
