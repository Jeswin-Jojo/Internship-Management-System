import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../models/login_request.dart';
import '../models/register_request.dart';
import '../utils/session_manager.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _auth = AuthService();

  bool isLoading = false;
  bool isLoggedIn = false;
  String? role;

  Future<bool> login(String email, String password) async {
    isLoading = true;
    notifyListeners();

    final success =
        await _auth.login(LoginRequest(email: email, password: password));

    if (success) {
      isLoggedIn = true;
      role = await SessionManager.getRole();
    }

    isLoading = false;
    notifyListeners();

    return success;
  }

  Future<bool> register(
      String name, String email, String password, String role) async {
    isLoading = true;
    notifyListeners();

    final success = await _auth.register(
      RegisterRequest(name: name, email: email, password: password, role: role),
    );

    isLoading = false;
    notifyListeners();

    return success;
  }

  Future<void> logout() async {
    await SessionManager.clear();
    isLoggedIn = false;
    role = null;
    notifyListeners();
  }
}