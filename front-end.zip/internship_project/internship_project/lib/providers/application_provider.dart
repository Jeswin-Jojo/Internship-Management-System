import 'package:flutter/material.dart';
import '../services/application_service.dart';
import 'dart:typed_data';

class ApplicationProvider extends ChangeNotifier {
  final ApplicationService _service = ApplicationService();

  bool isApplying = false;
  bool success = false;

  Future<bool> apply(int roleId, Uint8List fileBytes, String fileName) async {
    isApplying = true;
    notifyListeners();

    // service returns String? (null = success, message = error)
    final result =
        await _service.applyWithFile(roleId, fileBytes, fileName);

    success = result == null; // ✅ convert String? → bool

    isApplying = false;
    notifyListeners();

    return success;
  }
}