import 'package:flutter/material.dart';
import '../../models/mentor.dart';
import '../../services/mentor_service.dart';

class AdminManageMentorsPage extends StatefulWidget {
  @override
  State<AdminManageMentorsPage> createState() => _AdminManageMentorsPageState();
}

class _AdminManageMentorsPageState extends State<AdminManageMentorsPage> {
  List<Mentor> mentors = [];
  bool loading = true;
  bool saving = false;

  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadMentors();
  }

  Future<void> loadMentors() async {
    setState(() => loading = true);
    final result = await MentorService().getMentors();
    setState(() {
      mentors = result;
      loading = false;
    });
  }

  Future<void> addMentor() async {
    final name = nameController.text.trim();
    final email = emailController.text.trim();
    final phone = phoneController.text.trim();

    if (name.isEmpty || email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Name and Email are required"), backgroundColor: Colors.red[400]));
      return;
    }

    setState(() => saving = true);
    final ok = await MentorService().createMentor(name, email, phone);
    setState(() => saving = false);

    if (ok) {
      nameController.clear();
      emailController.clear();
      phoneController.clear();
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Mentor added successfully"), backgroundColor: Color(0xFF26C6A2)));
      await loadMentors();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Failed to add mentor"), backgroundColor: Colors.red[400]));
    }
  }

  Future<void> deleteMentor(int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text("Delete Mentor", style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF1A1744))),
        content: Text("Are you sure you want to delete this mentor?", style: TextStyle(color: Color(0xFF9B97CC))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Cancel", style: TextStyle(color: Color(0xFF9B97CC)))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red[400], foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () => Navigator.pop(context, true),
            child: Text("Delete"),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await MentorService().deleteMentor(id);
      await loadMentors();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("Manage Mentors"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
        actions: [IconButton(onPressed: loadMentors, icon: Icon(Icons.refresh_rounded))],
      ),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
          : Column(
              children: [
                // Add mentor form
                Container(
                  margin: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Color(0xFFEEECFF)),
                    boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.06), blurRadius: 16, offset: Offset(0, 4))],
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Container(width: 36, height: 36,
                              decoration: BoxDecoration(color: Color(0xFF26C6A2).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                              child: Icon(Icons.person_add_rounded, color: Color(0xFF26C6A2), size: 20)),
                          SizedBox(width: 10),
                          Text("Add New Mentor", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Color(0xFF1A1744))),
                        ]),
                        SizedBox(height: 16),
                        TextField(
                          controller: nameController,
                          decoration: InputDecoration(labelText: "Full Name *", prefixIcon: Icon(Icons.person_outline_rounded, color: Color(0xFF9B97CC))),
                        ),
                        SizedBox(height: 12),
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(labelText: "Email *", prefixIcon: Icon(Icons.email_outlined, color: Color(0xFF9B97CC))),
                        ),
                        SizedBox(height: 12),
                        TextField(
                          controller: phoneController,
                          keyboardType: TextInputType.phone,
                          decoration: InputDecoration(labelText: "Phone (optional)", prefixIcon: Icon(Icons.phone_outlined, color: Color(0xFF9B97CC))),
                        ),
                        SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: saving
                              ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
                              : ElevatedButton.icon(
                                  icon: Icon(Icons.person_add_rounded),
                                  label: Text("Add Mentor"),
                                  onPressed: addMentor,
                                ),
                        ),
                      ],
                    ),
                  ),
                ),

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                  child: Row(children: [
                    Text("${mentors.length} mentor(s)", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13, fontWeight: FontWeight.w500)),
                  ]),
                ),

                Expanded(
                  child: mentors.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(width: 70, height: 70, decoration: BoxDecoration(color: Color(0xFFF4F3FF), borderRadius: BorderRadius.circular(22)),
                                  child: Icon(Icons.people_outline_rounded, size: 34, color: Color(0xFFB0ACDB))),
                              SizedBox(height: 14),
                              Text("No mentors yet. Add one above.", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 14)),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: EdgeInsets.symmetric(horizontal: 16),
                          itemCount: mentors.length,
                          itemBuilder: (context, i) {
                            final m = mentors[i];
                            return Padding(
                              padding: EdgeInsets.only(bottom: 10),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: Color(0xFFEEECFF)),
                                ),
                                child: ListTile(
                                  contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                  leading: Container(
                                    width: 46, height: 46,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(colors: [Color(0xFF26C6A2), Color(0xFF43E8C0)]),
                                      borderRadius: BorderRadius.circular(14),
                                    ),
                                    child: Center(child: Text(m.name.isNotEmpty ? m.name[0].toUpperCase() : '?',
                                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18))),
                                  ),
                                  title: Text(m.name, style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF1A1744))),
                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(m.email, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
                                      if (m.phone.isNotEmpty) Text(m.phone, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
                                    ],
                                  ),
                                  trailing: IconButton(
                                    icon: Icon(Icons.delete_rounded, color: Colors.red[400]),
                                    onPressed: () => deleteMentor(m.id),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
