import 'package:flutter/material.dart';
import '../../services/role_service.dart';
import '../../models/internship_role.dart';

class AdminManageRolesPage extends StatefulWidget {
  @override
  State<AdminManageRolesPage> createState() => _AdminManageRolesPageState();
}

class _AdminManageRolesPageState extends State<AdminManageRolesPage> {
  List<InternshipRole> roles = [];
  bool loading = true;
  bool saving = false;

  final titleController = TextEditingController();
  final descriptionController = TextEditingController();

  @override
  void initState() {
    loadRoles();
    super.initState();
  }

  loadRoles() async {
    setState(() => loading = true);
    roles = await RoleService().getRoles();
    setState(() => loading = false);
  }

  addRole() async {
    if (titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Title is required"), backgroundColor: Colors.red[400]));
      return;
    }
    setState(() => saving = true);
    await RoleService().createRole(titleController.text.trim(), descriptionController.text.trim());
    titleController.clear();
    descriptionController.clear();
    setState(() => saving = false);
    await loadRoles();
  }

  deleteRole(int id) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text("Delete Role", style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF1A1744))),
        content: Text("Are you sure you want to delete this role?", style: TextStyle(color: Color(0xFF9B97CC))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text("Cancel", style: TextStyle(color: Color(0xFF9B97CC)))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red[400], foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            onPressed: () => Navigator.pop(context, true),
            child: Text("Delete"),
          ),
        ],
      ),
    );
    if (confirm == true) {
      await RoleService().deleteRole(id);
      await loadRoles();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("Manage Roles"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
        actions: [IconButton(icon: Icon(Icons.refresh_rounded), onPressed: loadRoles)],
      ),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
          : Column(children: [
              // Add Role Form
              Container(
                margin: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Color(0xFFEEECFF)),
                  boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.06), blurRadius: 16, offset: Offset(0, 4))],
                ),
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(width: 36, height: 36,
                          decoration: BoxDecoration(color: Color(0xFF6C63FF).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                          child: Icon(Icons.add_rounded, color: Color(0xFF6C63FF), size: 20)),
                      SizedBox(width: 10),
                      Text("Add New Role", style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Color(0xFF1A1744))),
                    ]),
                    SizedBox(height: 16),
                    TextField(controller: titleController, decoration: InputDecoration(labelText: "Role Title *", prefixIcon: Icon(Icons.work_rounded, size: 20, color: Color(0xFF9B97CC)))),
                    SizedBox(height: 12),
                    TextField(controller: descriptionController, maxLines: 2,
                        decoration: InputDecoration(labelText: "Description", prefixIcon: Icon(Icons.notes_rounded, size: 20, color: Color(0xFF9B97CC)))),
                    SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: saving
                          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
                          : ElevatedButton.icon(icon: Icon(Icons.add_rounded), label: Text("Add Role"), onPressed: addRole),
                    ),
                  ]),
                ),
              ),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 4),
                child: Row(children: [
                  Text("${roles.length} role(s)", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13, fontWeight: FontWeight.w500)),
                ]),
              ),
              Expanded(
                child: roles.isEmpty
                    ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Container(width: 70, height: 70, decoration: BoxDecoration(color: Color(0xFFF4F3FF), borderRadius: BorderRadius.circular(22)),
                            child: Icon(Icons.work_off_rounded, size: 34, color: Color(0xFFB0ACDB))),
                        SizedBox(height: 14),
                        Text("No roles added yet.", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 14)),
                      ]))
                    : ListView.builder(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        itemCount: roles.length,
                        itemBuilder: (context, i) {
                          final r = roles[i];
                          return Padding(
                            padding: EdgeInsets.only(bottom: 10),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Color(0xFFEEECFF)),
                              ),
                              child: ListTile(
                                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                leading: Container(width: 44, height: 44,
                                    decoration: BoxDecoration(color: Color(0xFF6C63FF).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                                    child: Icon(Icons.work_rounded, color: Color(0xFF6C63FF), size: 22)),
                                title: Text(r.title, style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF1A1744))),
                                subtitle: Text(r.description, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
                                trailing: IconButton(
                                  icon: Icon(Icons.delete_rounded, color: Colors.red[400]),
                                  onPressed: () => deleteRole(r.id),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ]),
    );
  }
}
