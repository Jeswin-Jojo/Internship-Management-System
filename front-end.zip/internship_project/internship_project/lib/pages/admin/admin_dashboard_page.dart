import 'package:flutter/material.dart';
import 'admin_manage_roles_page.dart';
import 'admin_manage_applications_page.dart';
import 'admin_manage_mentors_page.dart';
import '../../utils/session_manager.dart';
import '../../services/user_service.dart';

class AdminDashboardPage extends StatefulWidget {
  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  String adminName = '';

  @override
  void initState() {
    super.initState();
    loadName();
  }

  loadName() async {
    String name = await SessionManager.getName();
    if (name.isEmpty) {
      try {
        final user = await UserService().getProfile();
        if (user != null && user.name.isNotEmpty) {
          await SessionManager.saveName(user.name);
          name = user.name;
        }
      } catch (_) {}
    }
    setState(() => adminName = name);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Admin banner with real name
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF4834D4), Color(0xFF6C63FF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: Color(0xFF4834D4).withOpacity(0.3), blurRadius: 24, offset: Offset(0, 10))],
            ),
            child: Row(children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: Colors.white.withOpacity(0.2),
                child: Text(
                  adminName.isNotEmpty ? adminName[0].toUpperCase() : 'A',
                  style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text("Welcome back,", style: TextStyle(color: Colors.white60, fontSize: 13)),
                Text(adminName.isNotEmpty ? adminName : "Admin",
                    style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700)),
                SizedBox(height: 4),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                  child: Text("Administrator", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                ),
              ])),
            ]),
          ),
          SizedBox(height: 28),
          Text("MANAGEMENT", style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFFB0ACDB), letterSpacing: 1.4)),
          SizedBox(height: 12),
          _tile(context, icon: Icons.work_rounded, color: Color(0xFF6C63FF),
              title: "Manage Roles", subtitle: "Add or remove internship positions", page: AdminManageRolesPage()),
          SizedBox(height: 10),
          _tile(context, icon: Icons.description_rounded, color: Color(0xFFFF7043),
              title: "View Applications", subtitle: "Review, accept or reject applicants", page: AdminManageApplicationsPage()),
          SizedBox(height: 10),
          _tile(context, icon: Icons.people_rounded, color: Color(0xFF26C6A2),
              title: "Manage Mentors", subtitle: "Add or remove mentors for interns", page: AdminManageMentorsPage()),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context, {required IconData icon, required Color color, required String title, required String subtitle, required Widget page}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Color(0xFFEEECFF)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.06), blurRadius: 16, offset: Offset(0, 4))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
          child: Padding(
            padding: EdgeInsets.all(18),
            child: Row(children: [
              Container(
                width: 50, height: 50,
                decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(14)),
                child: Icon(icon, color: color, size: 24),
              ),
              SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15, color: Color(0xFF1A1744))),
                SizedBox(height: 3),
                Text(subtitle, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
              ])),
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                child: Icon(Icons.arrow_forward_ios_rounded, color: color, size: 14),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

