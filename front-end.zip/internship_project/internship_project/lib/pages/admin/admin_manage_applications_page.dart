import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../models/internship_application.dart';
import '../../models/internship_role.dart';
import '../../services/application_service.dart';
import '../../services/mentor_service.dart';
import '../../services/role_service.dart';
import '../../models/mentor.dart';
import '../../utils/constants.dart';

class AdminManageApplicationsPage extends StatefulWidget {
  @override
  State<AdminManageApplicationsPage> createState() => _AdminManageApplicationsPageState();
}

class _AdminManageApplicationsPageState extends State<AdminManageApplicationsPage> {
  List<InternshipApplication> apps = [];
  bool loading = true;
  List<Mentor> mentors = [];
  Map<int, String> roleTitles = {}; // roleId -> title
  String filter = "All";

  @override
  void initState() {
    super.initState();
    loadData();
  }

  loadData() async {
    setState(() => loading = true);
    // Fetch apps, mentors, and roles in parallel
    final results = await Future.wait([
      ApplicationService().getApplications(),
      MentorService().getMentors(),
      RoleService().getRoles(),
    ]);
    apps = results[0] as List<InternshipApplication>;
    mentors = results[1] as List<Mentor>;
    final roles = results[2] as List<InternshipRole>;
    roleTitles = {for (var r in roles) r.id: r.title};
    setState(() => loading = false);
  }

  /// Get role title from app data or fallback to fetched roles map
  String _getRoleTitle(InternshipApplication a) {
    if (a.roleTitle.isNotEmpty) return a.roleTitle;
    return roleTitles[a.roleId] ?? 'Unknown Role';
  }

  acceptApp(InternshipApplication app) async {
    await ApplicationService().accept(app.id);
    // Decrement seats for this role
    try {
      final roles = await RoleService().getRoles();
      final matching = roles.where((r) => r.id == app.roleId).toList();
      if (matching.isNotEmpty) {
        final role = matching.first;
        await RoleService().decrementSeats(role.id, role.title, role.description, role.availableSeats);
      }
    } catch (_) {}
    loadData();
  }

  List<InternshipApplication> get filtered =>
      filter == "All" ? apps : apps.where((a) => a.status == filter).toList();

  Color _statusColor(String s) {
    if (s == "Accepted") return Color(0xFF26C6A2);
    if (s == "Rejected") return Color(0xFFFF5252);
    return Color(0xFFFFB300);
  }

  // FIXED: uses dialogContext so Navigator.pop closes the dialog correctly
  void _showRejectDialog(InternshipApplication a) {
    final ctrl = TextEditingController(text: "Rejected by admin");
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text("Reject Application", style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF1A1744))),
        content: TextField(
          controller: ctrl,
          decoration: InputDecoration(
            labelText: "Rejection Reason",
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: Color(0xFF6C63FF)),
            ),
          ),
          maxLines: 3,
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text("Cancel", style: TextStyle(color: Color(0xFF9B97CC))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[400],
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () async {
              final reason = ctrl.text.trim().isEmpty ? "Rejected by admin" : ctrl.text.trim();
              Navigator.pop(dialogContext); // close dialog first using dialog's own context
              final ok = await ApplicationService().reject(a.id, reason);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: Text(ok ? "Application rejected." : "Failed to reject. Try again."),
                  backgroundColor: ok ? Colors.red[400] : Colors.grey,
                ));
              }
              loadData();
            },
            child: Text("Confirm Reject"),
          ),
        ],
      ),
    );
  }

  void _showAssignMentorSheet(InternshipApplication a) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          child: Container(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.75,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(24),
              ),
            ),
            child: Column(
              children: [
                Container(
                  width: 40,
                  height: 4,
                  margin: EdgeInsets.only(top: 12),
                  decoration: BoxDecoration(
                    color: Color(0xFFEEECFF),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    "Assign Mentor",
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1A1744),
                    ),
                  ),
                ),
                Divider(height: 1, color: Color(0xFFEEECFF)),
                Expanded(
                  child: mentors.isEmpty
                      ? Center(
                          child: Padding(
                            padding: EdgeInsets.all(20),
                            child: Text(
                              "No mentors available.",
                              style: TextStyle(color: Color(0xFF9B97CC)),
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: EdgeInsets.only(bottom: 20),
                          itemCount: mentors.length,
                          itemBuilder: (context, index) {
                            final m = mentors[index];

                            return ListTile(
                              contentPadding: EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 4,
                              ),
                              leading: Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Color(0xFF26C6A2),
                                      Color(0xFF43E8C0),
                                    ],
                                  ),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Center(
                                  child: Text(
                                    m.name[0].toUpperCase(),
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              title: Text(
                                m.name,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF1A1744),
                                ),
                              ),
                              subtitle: Text(
                                m.email,
                                style: TextStyle(
                                  color: Color(0xFF9B97CC),
                                  fontSize: 12,
                                ),
                              ),
                              onTap: () async {
                                Navigator.pop(sheetContext);

                                await ApplicationService().assignMentor(
                                  a.id,
                                  m.id,
                                );

                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        "Mentor assigned: ${m.name}",
                                      ),
                                      backgroundColor: Color(0xFF26C6A2),
                                    ),
                                  );
                                }

                                loadData();
                              },
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _openCv(String cvPath) async {
    try {
      final url = Constants.baseUrl.replaceAll('/api', '') + cvPath;
      final uri = Uri.parse(url);

      if (await canLaunchUrl(uri)) {
        await launchUrl(
          uri,
          mode: LaunchMode.externalApplication,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Unable to open CV')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening CV')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("Applications"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
        actions: [IconButton(icon: Icon(Icons.refresh_rounded), onPressed: loadData)],
      ),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
          : Column(children: [
              // Filter chips
              Padding(
                padding: EdgeInsets.fromLTRB(16, 14, 16, 6),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(children: ["All", "Pending", "Accepted", "Rejected"].map((f) {
                    final isSelected = filter == f;
                    final chipColor = f == "Accepted"
                        ? Color(0xFF26C6A2)
                        : f == "Rejected"
                            ? Color(0xFFFF5252)
                            : f == "Pending"
                                ? Color(0xFFFFB300)
                                : Color(0xFF6C63FF);
                    return Padding(
                      padding: EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => filter = f),
                        child: AnimatedContainer(
                          duration: Duration(milliseconds: 150),
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: isSelected ? chipColor.withOpacity(0.12) : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: isSelected ? chipColor : Color(0xFFEEECFF), width: isSelected ? 1.5 : 1),
                          ),
                          child: Text(f, style: TextStyle(
                            color: isSelected ? chipColor : Color(0xFF9B97CC),
                            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                            fontSize: 13,
                          )),
                        ),
                      ),
                    );
                  }).toList()),
                ),
              ),
              Expanded(
                child: filtered.isEmpty
                    ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Container(width: 70, height: 70, decoration: BoxDecoration(color: Color(0xFFF4F3FF), borderRadius: BorderRadius.circular(22)),
                            child: Icon(Icons.inbox_rounded, size: 34, color: Color(0xFFB0ACDB))),
                        SizedBox(height: 14),
                        Text("No applications found.", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 14)),
                      ]))
                    : ListView.builder(
                        padding: EdgeInsets.all(16),
                        itemCount: filtered.length,
                        itemBuilder: (context, i) {
                          final a = filtered[i];
                          final color = _statusColor(a.status);
                          final roleTitle = _getRoleTitle(a);
                          return Padding(
                            padding: EdgeInsets.only(bottom: 12),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: Color(0xFFEEECFF)),
                                boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.04), blurRadius: 16, offset: Offset(0, 4))],
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(18),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  // Header row: avatar + name + status badge
                                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                    Expanded(child: Row(children: [
                                      Container(
                                        width: 42, height: 42,
                                        decoration: BoxDecoration(color: Color(0xFF6C63FF).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                                        child: Center(child: Text(
                                          a.userName.isNotEmpty ? a.userName[0].toUpperCase() : 'U',
                                          style: TextStyle(color: Color(0xFF6C63FF), fontWeight: FontWeight.bold, fontSize: 16),
                                        )),
                                      ),
                                      SizedBox(width: 12),
                                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                        Text(a.userName.isNotEmpty ? a.userName : 'Unknown Student',
                                            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: Color(0xFF1A1744))),
                                        SizedBox(height: 2),
                                        Text(roleTitle, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
                                      ])),
                                    ])),
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                                      decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                                      child: Text(a.status, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12)),
                                    ),
                                  ]),
                                  SizedBox(height: 14),
                                  Divider(height: 1, color: Color(0xFFEEECFF)),
                                  SizedBox(height: 12),
                                  // Role detail row
                                  Row(children: [
                                    Icon(Icons.work_rounded, size: 15, color: Color(0xFFB0ACDB)),
                                    SizedBox(width: 8),
                                    Text("Role: ", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13)),
                                    Expanded(child: Text(roleTitle, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Color(0xFF1A1744)))),
                                  ]),
                                  // CV link
                                  if (a.cvLink.isNotEmpty) ...[
                                    SizedBox(height: 8),
                                    Row(children: [
                                      Icon(Icons.attach_file_rounded, size: 15, color: Color(0xFFB0ACDB)),
                                      SizedBox(width: 8),
                                      Text("CV: ", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13)),
                                      Expanded(
                                        child: TextButton.icon(
                                          onPressed: () => _openCv(a.cvLink),
                                          icon: Icon(Icons.visibility_rounded, size: 16),
                                          label: Text("View CV"),
                                          style: TextButton.styleFrom(
                                            alignment: Alignment.centerLeft,
                                            foregroundColor: Color(0xFF6C63FF),
                                            padding: EdgeInsets.zero,
                                          ),
                                        ),
                                      ),
                                    ]),
                                  ],
                                  // Rejection reason
                                  if (a.rejectionReason != null && a.rejectionReason!.isNotEmpty) ...[
                                    SizedBox(height: 10),
                                    Container(
                                      padding: EdgeInsets.all(10),
                                      decoration: BoxDecoration(color: Color(0xFFFF5252).withOpacity(0.06), borderRadius: BorderRadius.circular(10), border: Border.all(color: Color(0xFFFF5252).withOpacity(0.2))),
                                      child: Row(children: [
                                        Icon(Icons.info_rounded, size: 14, color: Color(0xFFFF5252)),
                                        SizedBox(width: 8),
                                        Expanded(child: Text("Reason: ${a.rejectionReason}", style: TextStyle(color: Color(0xFFD32F2F), fontSize: 12))),
                                      ]),
                                    ),
                                  ],
                                  SizedBox(height: 14),
                                  // Action buttons
                                  if (a.status == "Pending") Row(children: [
                                    Expanded(child: ElevatedButton.icon(
                                      icon: Icon(Icons.check_rounded, size: 16),
                                      label: Text("Accept"),
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFF26C6A2), foregroundColor: Colors.white,
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                        padding: EdgeInsets.symmetric(vertical: 12),
                                      ),
                                      onPressed: () => acceptApp(a),
                                    )),
                                    SizedBox(width: 10),
                                    Expanded(child: OutlinedButton.icon(
                                      icon: Icon(Icons.close_rounded, size: 16),
                                      label: Text("Reject"),
                                      style: OutlinedButton.styleFrom(
                                        foregroundColor: Color(0xFFFF5252),
                                        side: BorderSide(color: Color(0xFFFF5252)),
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                        padding: EdgeInsets.symmetric(vertical: 12),
                                      ),
                                      onPressed: () => _showRejectDialog(a),
                                    )),
                                  ]),
                                  if (a.status == "Accepted") SizedBox(
                                    width: double.infinity,
                                    child: ElevatedButton.icon(
                                      icon: Icon(Icons.person_add_rounded, size: 16),
                                      label: Text("Assign Mentor"),
                                      style: ElevatedButton.styleFrom(
                                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                        padding: EdgeInsets.symmetric(vertical: 12),
                                      ),
                                      onPressed: () => _showAssignMentorSheet(a),
                                    ),
                                  ),
                                ]),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ]),
    );
  }
}
