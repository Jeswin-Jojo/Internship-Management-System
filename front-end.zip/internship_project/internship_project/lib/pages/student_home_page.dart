import 'package:flutter/material.dart';
import 'student_roles_page.dart';
import 'student_applications_page.dart';
import 'student_mentor_page.dart';
import '../providers/auth_provider.dart';
import 'package:provider/provider.dart';
import '../pages/login_page.dart';
import '../utils/session_manager.dart';
import '../services/user_service.dart';

class StudentHomePage extends StatefulWidget {
  @override
  State<StudentHomePage> createState() => _StudentHomePageState();
}

class _StudentHomePageState extends State<StudentHomePage> {
  String studentName = '';

  @override
  void initState() {
    super.initState();
    loadName();
  }

  loadName() async {
    String name = await SessionManager.getName();
    if (name.isEmpty) {
      // Fallback: fetch from API and save for next time
      try {
        final user = await UserService().getProfile();
        if (user != null && user.name.isNotEmpty) {
          await SessionManager.saveName(user.name);
          name = user.name;
        }
      } catch (_) {}
    }
    setState(() => studentName = name);
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 30, height: 30,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
            child: Icon(Icons.business_center_rounded, color: Colors.white, size: 17),
          ),
          SizedBox(width: 10),
          Text("Internship Portal"),
        ]),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)], begin: Alignment.centerLeft, end: Alignment.centerRight),
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 8),
            child: TextButton.icon(
              icon: Icon(Icons.logout_rounded, color: Colors.white70, size: 18),
              label: Text("Logout", style: TextStyle(color: Colors.white70, fontFamily: 'Poppins')),
              onPressed: () {
                auth.logout();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginPage()));
              },
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome banner
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.3), blurRadius: 24, offset: Offset(0, 10))],
              ),
              child: Row(children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white.withOpacity(0.2),
                  child: Text(
                    studentName.isNotEmpty ? studentName[0].toUpperCase() : 'S',
                    style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text("Welcome back,", style: TextStyle(color: Colors.white60, fontSize: 13)),
                  Text(studentName.isNotEmpty ? studentName : "Student",
                      style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
                  SizedBox(height: 4),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                    child: Text("Student", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                  ),
                ])),
              ]),
            ),

            SizedBox(height: 28),
            Text("QUICK ACTIONS", style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Color(0xFFB0ACDB), letterSpacing: 1.4)),
            SizedBox(height: 12),

            _actionTile(
              icon: Icons.work_rounded, color: Color(0xFF6C63FF),
              title: "Apply for Internship",
              subtitle: "Browse and apply for available internship roles",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StudentRolesPage())),
            ),
            SizedBox(height: 10),
            _actionTile(
              icon: Icons.description_rounded, color: Color(0xFFFF7043),
              title: "My Applications",
              subtitle: "Track the status of your internship applications",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StudentApplicationsPage())),
            ),
            SizedBox(height: 10),
            _actionTile(
              icon: Icons.people_rounded, color: Color(0xFF26C6A2),
              title: "My Mentor",
              subtitle: "View your assigned mentor's contact details",
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StudentMentorPage())),
            ),
          ],
        ),
      ),
    );
  }

  Widget _actionTile({required IconData icon, required Color color, required String title, required String subtitle, required VoidCallback onTap}) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Color(0xFFEEECFF)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.06), blurRadius: 16, offset: Offset(0, 4))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: EdgeInsets.all(18),
            child: Row(children: [
              Container(
                width: 50, height: 50,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15, color: Color(0xFF1A1744))),
                SizedBox(height: 3),
                Text(subtitle, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
              ])),
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                child: Icon(Icons.arrow_forward_ios_rounded, color: color, size: 14),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
