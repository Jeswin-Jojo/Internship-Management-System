import 'package:flutter/material.dart';
import '../services/application_service.dart';
import '../services/role_service.dart';
import '../models/internship_application.dart';
import '../models/internship_role.dart';

class StudentApplicationsPage extends StatefulWidget {
  @override
  State<StudentApplicationsPage> createState() => _StudentApplicationsPageState();
}

class _StudentApplicationsPageState extends State<StudentApplicationsPage> {
  bool loading = true;
  List<InternshipApplication> apps = [];
  Map<int, String> roleTitles = {}; // roleId -> title lookup map

  @override
  void initState() {
    super.initState();
    loadApps();
  }

  loadApps() async {
    setState(() => loading = true);
    // Fetch applications and all roles in parallel
    final results = await Future.wait([
      ApplicationService().getMyApplications(),
      RoleService().getRoles(),
    ]);
    apps = results[0] as List<InternshipApplication>;
    final roles = results[1] as List<InternshipRole>;
    // Build a roleId -> title map for quick lookup
    roleTitles = {for (var r in roles) r.id: r.title};
    setState(() => loading = false);
  }

  /// Get role title: prefer from app itself, fallback to fetched roles map
  String _getRoleTitle(InternshipApplication app) {
    if (app.roleTitle.isNotEmpty) return app.roleTitle;
    return roleTitles[app.roleId] ?? 'Unknown Role';
  }

  Color _statusColor(String s) {
    if (s == "Accepted") return Color(0xFF26C6A2);
    if (s == "Rejected") return Color(0xFFFF5252);
    return Color(0xFFFFB300);
  }

  IconData _statusIcon(String s) {
    if (s == "Accepted") return Icons.check_circle_rounded;
    if (s == "Rejected") return Icons.cancel_rounded;
    return Icons.hourglass_empty_rounded;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("My Applications"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
        actions: [IconButton(icon: Icon(Icons.refresh_rounded), onPressed: loadApps)],
      ),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
          : apps.isEmpty
              ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 80, height: 80,
                    decoration: BoxDecoration(color: Color(0xFFF4F3FF), borderRadius: BorderRadius.circular(24)),
                    child: Icon(Icons.inbox_rounded, size: 38, color: Color(0xFFB0ACDB)),
                  ),
                  SizedBox(height: 16),
                  Text("No applications yet.", style: TextStyle(color: Color(0xFF1A1744), fontSize: 16, fontWeight: FontWeight.w600)),
                  SizedBox(height: 6),
                  Text("Apply for a role to get started.", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13)),
                ]))
              : ListView.builder(
                  padding: EdgeInsets.all(16),
                  itemCount: apps.length,
                  itemBuilder: (context, i) {
                    final app = apps[i];
                    final color = _statusColor(app.status);
                    final title = _getRoleTitle(app);
                    return Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Color(0xFFEEECFF)),
                          boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.05), blurRadius: 16, offset: Offset(0, 4))],
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(18),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text("Applied Role", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 11, fontWeight: FontWeight.w500, letterSpacing: 0.5)),
                                SizedBox(height: 2),
                                Text(title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: Color(0xFF1A1744))),
                              ])),
                              SizedBox(width: 12),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                                decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                                child: Row(mainAxisSize: MainAxisSize.min, children: [
                                  Icon(_statusIcon(app.status), size: 13, color: color),
                                  SizedBox(width: 5),
                                  Text(app.status, style: TextStyle(color: color, fontWeight: FontWeight.w600, fontSize: 12)),
                                ]),
                              ),
                            ]),
                            if (app.rejectionReason != null && app.rejectionReason!.isNotEmpty) ...[
                              SizedBox(height: 12),
                              Container(
                                padding: EdgeInsets.all(12),
                                decoration: BoxDecoration(color: Color(0xFFFF5252).withOpacity(0.06), borderRadius: BorderRadius.circular(12), border: Border.all(color: Color(0xFFFF5252).withOpacity(0.2))),
                                child: Row(children: [
                                  Icon(Icons.info_rounded, size: 16, color: Color(0xFFFF5252)),
                                  SizedBox(width: 10),
                                  Expanded(child: Text("Reason: ${app.rejectionReason}", style: TextStyle(color: Color(0xFFD32F2F), fontSize: 13))),
                                ]),
                              ),
                            ],
                            if (app.status == "Accepted") ...[
                              SizedBox(height: 12),
                              Container(
                                padding: EdgeInsets.all(12),
                                decoration: BoxDecoration(color: Color(0xFF26C6A2).withOpacity(0.06), borderRadius: BorderRadius.circular(12), border: Border.all(color: Color(0xFF26C6A2).withOpacity(0.2))),
                                child: Row(children: [
                                  Icon(Icons.celebration_rounded, size: 16, color: Color(0xFF26C6A2)),
                                  SizedBox(width: 10),
                                  Text("Congratulations! Your application was accepted.", style: TextStyle(color: Color(0xFF00796B), fontSize: 13)),
                                ]),
                              ),
                            ],
                          ]),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
