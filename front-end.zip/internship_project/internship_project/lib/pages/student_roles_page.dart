import 'package:flutter/material.dart';
import '../services/role_service.dart';
import '../models/internship_role.dart';
import 'student_role_apply_page.dart';

class StudentRolesPage extends StatefulWidget {
  @override
  State<StudentRolesPage> createState() => _StudentRolesPageState();
}

class _StudentRolesPageState extends State<StudentRolesPage> {
  List<InternshipRole> roles = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadRoles();
  }

  loadRoles() async {
    final allRoles = await RoleService().getRoles();
    // Only show roles that still have seats available
    roles = allRoles.where((r) => r.availableSeats > 0).toList();
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("Available Roles"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
        actions: [IconButton(icon: Icon(Icons.refresh_rounded), onPressed: () { setState(() => loading = true); loadRoles(); })],
      ),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
          : roles.isEmpty
              ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 80, height: 80,
                    decoration: BoxDecoration(color: Color(0xFFF4F3FF), borderRadius: BorderRadius.circular(24)),
                    child: Icon(Icons.work_off_outlined, size: 38, color: Color(0xFFB0ACDB)),
                  ),
                  SizedBox(height: 16),
                  Text("No roles available right now.", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 15, fontWeight: FontWeight.w500)),
                ]))
              : ListView.builder(
                  padding: EdgeInsets.all(16),
                  itemCount: roles.length,
                  itemBuilder: (context, i) {
                    final r = roles[i];
                    return Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Color(0xFFEEECFF)),
                          boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.05), blurRadius: 16, offset: Offset(0, 4))],
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(18),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Row(children: [
                              Container(
                                width: 46, height: 46,
                                decoration: BoxDecoration(color: Color(0xFF6C63FF).withOpacity(0.1), borderRadius: BorderRadius.circular(14)),
                                child: Icon(Icons.work_rounded, color: Color(0xFF6C63FF), size: 22),
                              ),
                              SizedBox(width: 14),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(r.title, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: Color(0xFF1A1744))),
                                SizedBox(height: 4),
                                Row(children: [
                                  Icon(Icons.event_seat_rounded, size: 13, color: Color(0xFF9B97CC)),
                                  SizedBox(width: 4),
                                  Text("${r.availableSeats} seats available", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
                                ]),
                              ])),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(color: Color(0xFF26C6A2).withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                                child: Text("Open", style: TextStyle(color: Color(0xFF26C6A2), fontSize: 11, fontWeight: FontWeight.w600)),
                              ),
                            ]),
                            SizedBox(height: 12),
                            Text(r.description, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13, height: 1.5)),
                            SizedBox(height: 16),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => StudentRoleApplyPage(role: r))),
                                child: Text("Apply Now"),
                              ),
                            ),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
