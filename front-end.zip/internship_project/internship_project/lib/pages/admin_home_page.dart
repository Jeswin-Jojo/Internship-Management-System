import 'package:flutter/material.dart';
import '../providers/auth_provider.dart';
import 'package:provider/provider.dart';
import '../pages/login_page.dart';
import 'admin/admin_dashboard_page.dart';

class AdminHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 30, height: 30,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
            child: Icon(Icons.business_center_rounded, color: Colors.white, size: 17),
          ),
          SizedBox(width: 10),
          Text("Admin Dashboard"),
        ]),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFF4834D4), Color(0xFF6C63FF)], begin: Alignment.centerLeft, end: Alignment.centerRight),
          ),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 8),
            child: TextButton.icon(
              icon: Icon(Icons.logout_rounded, color: Colors.white70, size: 18),
              label: Text("Logout", style: TextStyle(color: Colors.white70, fontFamily: 'Poppins')),
              onPressed: () {
                auth.logout();
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => LoginPage()));
              },
            ),
          ),
        ],
      ),
      backgroundColor: Color(0xFFF8F7FF),
      body: AdminDashboardPage(),
    );
  }
}
