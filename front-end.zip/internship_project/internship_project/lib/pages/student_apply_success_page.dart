import 'package:flutter/material.dart';

class StudentApplySuccessPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100, height: 100,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Color(0xFF26C6A2), Color(0xFF43E8C0)]),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: Color(0xFF26C6A2).withOpacity(0.35), blurRadius: 24, offset: Offset(0, 10))],
                ),
                child: Icon(Icons.check_rounded, color: Colors.white, size: 52),
              ),
              SizedBox(height: 28),
              Text("Application Submitted!", style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: Color(0xFF1A1744), letterSpacing: -0.5)),
              SizedBox(height: 10),
              Text("You will be notified once approved.", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 15)),
              SizedBox(height: 36),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text("Back to Home"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
