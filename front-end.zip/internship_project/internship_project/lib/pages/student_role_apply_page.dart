import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import '../models/internship_role.dart';
import '../utils/constants.dart';
import '../utils/session_manager.dart';

class StudentRoleApplyPage extends StatefulWidget {
  final InternshipRole role;
  StudentRoleApplyPage({required this.role});

  @override
  State<StudentRoleApplyPage> createState() => _StudentRoleApplyPageState();
}

class _StudentRoleApplyPageState extends State<StudentRoleApplyPage> {
  bool loading = false;
  String? selectedFileName;
  Uint8List? selectedFileBytes;

  Future<void> pickCvFile() async {
    // On Flutter Web, use withData:true and access bytes (no file path available)
    final result = await FilePicker.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'doc', 'docx'],
      withData: true,   // ← required for web
      withReadStream: false,
    );

    if (result != null && result.files.isNotEmpty) {
      final file = result.files.first;
      if (file.bytes != null) {
        setState(() {
          selectedFileName = file.name;
          selectedFileBytes = file.bytes;
        });
      }
    }
  }

  Future<String?> submitApplication() async {
    final token = await SessionManager.getToken();
    final userId = await SessionManager.getUserId();

    final uri = Uri.parse('${Constants.baseUrl}/Applications');
    final request = http.MultipartRequest('POST', uri);

    request.headers['Authorization'] = 'Bearer $token';
    request.fields['userId'] = userId.toString();
    request.fields['internshipRoleId'] = widget.role.id.toString();

    request.files.add(http.MultipartFile.fromBytes(
      'cvFile',
      selectedFileBytes!,
      filename: selectedFileName!,
    ));

    try {
      final streamed = await request.send();
      final response = await http.Response.fromStream(streamed);

      if (response.statusCode == 200 || response.statusCode == 201) {
        return null; // success
      }

      final data = jsonDecode(response.body);
      return data is String ? data : (data['message'] ?? 'Failed to apply (${response.statusCode})');
    } catch (e) {
      return 'Error: $e';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("Apply for Internship"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Role info card
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.25), blurRadius: 20, offset: Offset(0, 8))],
              ),
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Applying for", style: TextStyle(color: Colors.white60, fontSize: 12)),
                  SizedBox(height: 4),
                  Text(widget.role.title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Colors.white)),
                  SizedBox(height: 8),
                  Text(widget.role.description, style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.5)),
                  SizedBox(height: 12),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.event_seat_rounded, size: 15, color: Colors.white),
                      SizedBox(width: 6),
                      Text("${widget.role.availableSeats} seats available", style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                ],
              ),
            ),

            SizedBox(height: 28),
            Text("Upload Your CV", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF1A1744))),
            SizedBox(height: 4),
            Text("Accepted formats: PDF, DOC, DOCX", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13)),
            SizedBox(height: 14),

            // File picker box
            GestureDetector(
              onTap: pickCvFile,
              child: AnimatedContainer(
                duration: Duration(milliseconds: 200),
                width: double.infinity,
                padding: EdgeInsets.all(28),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: selectedFileName != null ? Color(0xFF6C63FF) : Color(0xFFD6D3F0),
                    width: selectedFileName != null ? 2 : 1.5,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  color: selectedFileName != null ? Color(0xFF6C63FF).withOpacity(0.05) : Color(0xFFF8F7FF),
                ),
                child: Column(
                  children: [
                    Container(
                      width: 60, height: 60,
                      decoration: BoxDecoration(
                        color: selectedFileName != null ? Color(0xFF6C63FF).withOpacity(0.1) : Color(0xFFF0EEFF),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(
                        selectedFileName != null ? Icons.description_rounded : Icons.upload_file_rounded,
                        size: 30,
                        color: selectedFileName != null ? Color(0xFF6C63FF) : Color(0xFFB0ACDB),
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      selectedFileName ?? "Click to select your CV file",
                      style: TextStyle(
                        color: selectedFileName != null ? Color(0xFF6C63FF) : Color(0xFF9B97CC),
                        fontWeight: selectedFileName != null ? FontWeight.w600 : FontWeight.normal,
                        fontSize: 14,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    if (selectedFileName == null) ...[
                      SizedBox(height: 4),
                      Text("PDF, DOC, DOCX", style: TextStyle(color: Color(0xFFB0ACDB), fontSize: 12)),
                    ],
                  ],
                ),
              ),
            ),

            if (selectedFileName != null) ...[
              SizedBox(height: 10),
              Row(children: [
                Icon(Icons.check_circle_rounded, color: Color(0xFF26C6A2), size: 17),
                SizedBox(width: 6),
                Text("File selected", style: TextStyle(color: Color(0xFF26C6A2), fontWeight: FontWeight.w500)),
                Spacer(),
                TextButton(onPressed: pickCvFile, child: Text("Change file", style: TextStyle(color: Color(0xFF6C63FF)))),
              ]),
            ],

            SizedBox(height: 32),

            SizedBox(
              width: double.infinity,
              child: loading
                  ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
                  : ElevatedButton.icon(
                      icon: Icon(Icons.send_rounded),
                      label: Text("Submit Application"),
                      onPressed: selectedFileBytes == null
                          ? null
                          : () async {
                              setState(() => loading = true);
                              final error = await submitApplication();
                              setState(() => loading = false);

                              if (error == null) {
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                  content: Text("Application submitted successfully!"),
                                  backgroundColor: Color(0xFF26C6A2),
                                ));
                                Navigator.pop(context);
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                  content: Text(error),
                                  backgroundColor: Colors.red[400],
                                ));
                              }
                            },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
