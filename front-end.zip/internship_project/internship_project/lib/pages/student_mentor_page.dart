import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/assignment_service.dart';
import '../models/internship_assignment.dart';
import '../utils/session_manager.dart';

class StudentMentorPage extends StatefulWidget {
  @override
  State<StudentMentorPage> createState() => _StudentMentorPageState();
}

class _StudentMentorPageState extends State<StudentMentorPage> {
  bool loading = true;
  InternshipAssignment? assignment;

  @override
  void initState() {
    super.initState();
    loadAssignment();
  }

  loadAssignment() async {
    final userId = await SessionManager.getUserId();
    final all = await AssignmentService().getMyAssignment(userId);
    setState(() {
      assignment = all;
      loading = false;
    });
  }

  void _copy(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("$label copied!"), duration: Duration(seconds: 1)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("My Mentor"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
        actions: [IconButton(icon: Icon(Icons.refresh_rounded), onPressed: () { setState(() => loading = true); loadAssignment(); })],
      ),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
          : assignment == null
              ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Container(
                    width: 90, height: 90,
                    decoration: BoxDecoration(color: Color(0xFFF4F3FF), borderRadius: BorderRadius.circular(28)),
                    child: Icon(Icons.person_search_rounded, size: 44, color: Color(0xFFB0ACDB)),
                  ),
                  SizedBox(height: 20),
                  Text("No mentor assigned yet.", style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: Color(0xFF1A1744))),
                  SizedBox(height: 8),
                  Text("A mentor will be assigned after\nyour application is accepted.",
                      textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 14, height: 1.6)),
                ]))
              : SingleChildScrollView(
                  padding: EdgeInsets.all(20),
                  child: Column(children: [
                    // Mentor profile card
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: Color(0xFFEEECFF)),
                        boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.08), blurRadius: 30, offset: Offset(0, 12))],
                      ),
                      child: Padding(
                        padding: EdgeInsets.all(28),
                        child: Column(children: [
                          Container(
                            width: 80, height: 80,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]),
                              borderRadius: BorderRadius.circular(24),
                              boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.3), blurRadius: 16, offset: Offset(0, 6))],
                            ),
                            child: Center(child: Text(
                              assignment!.mentorName.isNotEmpty ? assignment!.mentorName[0].toUpperCase() : '?',
                              style: TextStyle(fontSize: 32, color: Colors.white, fontWeight: FontWeight.bold),
                            )),
                          ),
                          SizedBox(height: 16),
                          Text(assignment!.mentorName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: Color(0xFF1A1744))),
                          SizedBox(height: 8),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                            decoration: BoxDecoration(color: Color(0xFF6C63FF).withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                            child: Text("Your Assigned Mentor", style: TextStyle(color: Color(0xFF6C63FF), fontSize: 12, fontWeight: FontWeight.w600)),
                          ),
                          SizedBox(height: 24),
                          Divider(color: Color(0xFFEEECFF)),
                          SizedBox(height: 16),
                          _contactRow(Icons.email_outlined, "Email", assignment!.mentorEmail, () => _copy(assignment!.mentorEmail, "Email")),
                          if (assignment!.mentorPhone.isNotEmpty) ...[
                            SizedBox(height: 10),
                            _contactRow(Icons.phone_outlined, "Phone", assignment!.mentorPhone, () => _copy(assignment!.mentorPhone, "Phone")),
                          ],
                          if (assignment!.roleTitle.isNotEmpty) ...[
                            SizedBox(height: 10),
                            _contactRow(Icons.work_rounded, "Role", assignment!.roleTitle, null),
                          ],
                        ]),
                      ),
                    ),
                    SizedBox(height: 16),
                    Container(
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Color(0xFF6C63FF).withOpacity(0.06),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Color(0xFF6C63FF).withOpacity(0.15)),
                      ),
                      child: Row(children: [
                        Icon(Icons.info_rounded, color: Color(0xFF6C63FF), size: 18),
                        SizedBox(width: 12),
                        Expanded(child: Text("Feel free to reach out to your mentor for guidance during your internship.",
                            style: TextStyle(color: Color(0xFF4834D4), fontSize: 13, height: 1.5))),
                      ]),
                    ),
                  ]),
                ),
    );
  }

  Widget _contactRow(IconData icon, String label, String value, VoidCallback? onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(color: Color(0xFFF8F7FF), borderRadius: BorderRadius.circular(14), border: Border.all(color: Color(0xFFEEECFF))),
        child: Row(children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(color: Color(0xFF6C63FF).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, size: 18, color: Color(0xFF6C63FF)),
          ),
          SizedBox(width: 14),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: TextStyle(fontSize: 11, color: Color(0xFF9B97CC), fontWeight: FontWeight.w500)),
            Text(value, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: Color(0xFF1A1744))),
          ]),
          if (onTap != null) ...[Spacer(), Icon(Icons.copy_rounded, size: 16, color: Color(0xFFB0ACDB))],
        ]),
      ),
    );
  }
}
