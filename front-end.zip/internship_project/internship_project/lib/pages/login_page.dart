import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'register_page.dart';
import 'student_home_page.dart';
import 'admin_home_page.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool obscure = true;

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      body: Center(
        child: SingleChildScrollView(
          child: SizedBox(
            width: 420,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 48),
              child: Column(
                children: [
                  // Logo area
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: [
                        BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.35), blurRadius: 20, offset: Offset(0, 8)),
                      ],
                    ),
                    child: Icon(Icons.business_center_rounded, color: Colors.white, size: 34),
                  ),
                  SizedBox(height: 20),
                  Text("Internship Portal", style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: Color(0xFF1A1744), letterSpacing: -0.5)),
                  SizedBox(height: 6),
                  Text("Sign in to continue", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 15)),
                  SizedBox(height: 36),

                  // Card
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.08), blurRadius: 40, offset: Offset(0, 16))],
                      border: Border.all(color: Color(0xFFEEECFF)),
                    ),
                    padding: EdgeInsets.all(32),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Email", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Color(0xFF1A1744))),
                        SizedBox(height: 8),
                        TextField(
                          controller: email,
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                            hintText: "you@example.com",
                            prefixIcon: Icon(Icons.email_outlined, size: 20, color: Color(0xFF9B97CC)),
                          ),
                        ),
                        SizedBox(height: 20),
                        Text("Password", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Color(0xFF1A1744))),
                        SizedBox(height: 8),
                        TextField(
                          controller: password,
                          obscureText: obscure,
                          decoration: InputDecoration(
                            hintText: "••••••••",
                            prefixIcon: Icon(Icons.lock_outline_rounded, size: 20, color: Color(0xFF9B97CC)),
                            suffixIcon: IconButton(
                              icon: Icon(obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20, color: Color(0xFF9B97CC)),
                              onPressed: () => setState(() => obscure = !obscure),
                            ),
                          ),
                        ),
                        SizedBox(height: 28),
                        auth.isLoading
                            ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
                            : SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: () async {
                                    bool ok = await auth.login(email.text.trim(), password.text.trim());
                                    if (!ok) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(content: Text("Invalid credentials"), backgroundColor: Colors.red[400]));
                                      return;
                                    }
                                    if (auth.role?.toLowerCase() == "admin") {
                                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => AdminHomePage()));
                                    } else {
                                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => StudentHomePage()));
                                    }
                                  },
                                  child: Text("Sign In"),
                                ),
                              ),
                        SizedBox(height: 20),
                        Center(
                          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Text("Don't have an account? ", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13)),
                            GestureDetector(
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => RegisterPage())),
                              child: Text("Register", style: TextStyle(color: Color(0xFF6C63FF), fontWeight: FontWeight.w700, fontSize: 13)),
                            ),
                          ]),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
