import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class RegisterPage extends StatefulWidget {
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  String role = "Student";
  bool obscure = true;

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);

    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      body: Center(
        child: SingleChildScrollView(
          child: SizedBox(
            width: 420,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 48),
              child: Column(
                children: [
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Color(0xFF43C59E), Color(0xFF6C63FF)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: [BoxShadow(color: Color(0xFF43C59E).withOpacity(0.35), blurRadius: 20, offset: Offset(0, 8))],
                    ),
                    child: Icon(Icons.person_add_rounded, color: Colors.white, size: 32),
                  ),
                  SizedBox(height: 20),
                  Text("Create Account", style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: Color(0xFF1A1744), letterSpacing: -0.5)),
                  SizedBox(height: 6),
                  Text("Join the Internship Portal", style: TextStyle(color: Color(0xFF9B97CC), fontSize: 15)),
                  SizedBox(height: 36),

                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24),
                      boxShadow: [BoxShadow(color: Color(0xFF6C63FF).withOpacity(0.08), blurRadius: 40, offset: Offset(0, 16))],
                      border: Border.all(color: Color(0xFFEEECFF)),
                    ),
                    padding: EdgeInsets.all(32),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Full Name", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Color(0xFF1A1744))),
                        SizedBox(height: 8),
                        TextField(controller: name, decoration: InputDecoration(hintText: "John Doe", prefixIcon: Icon(Icons.person_outline_rounded, size: 20, color: Color(0xFF9B97CC)))),
                        SizedBox(height: 18),
                        Text("Email", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Color(0xFF1A1744))),
                        SizedBox(height: 8),
                        TextField(controller: email, keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(hintText: "you@example.com", prefixIcon: Icon(Icons.email_outlined, size: 20, color: Color(0xFF9B97CC)))),
                        SizedBox(height: 18),
                        Text("Password", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Color(0xFF1A1744))),
                        SizedBox(height: 8),
                        TextField(
                          controller: password, obscureText: obscure,
                          decoration: InputDecoration(
                            hintText: "Min. 6 characters",
                            prefixIcon: Icon(Icons.lock_outline_rounded, size: 20, color: Color(0xFF9B97CC)),
                            suffixIcon: IconButton(
                              icon: Icon(obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20, color: Color(0xFF9B97CC)),
                              onPressed: () => setState(() => obscure = !obscure),
                            ),
                          ),
                        ),
                        SizedBox(height: 18),
                        Text("Role", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: Color(0xFF1A1744))),
                        SizedBox(height: 8),
                        DropdownButtonFormField<String>(
                          value: role,
                          decoration: InputDecoration(prefixIcon: Icon(Icons.badge_outlined, size: 20, color: Color(0xFF9B97CC))),
                          items: [
                            DropdownMenuItem(value: "Student", child: Text("Student")),
                            DropdownMenuItem(value: "Admin", child: Text("Admin")),
                          ],
                          onChanged: (val) => setState(() => role = val!),
                        ),
                        SizedBox(height: 28),
                        auth.isLoading
                            ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
                            : SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: () async {
                                    bool ok = await auth.register(name.text.trim(), email.text.trim(), password.text.trim(), role);
                                    if (ok) {
                                      Navigator.pop(context);
                                    } else {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(content: Text("Registration failed"), backgroundColor: Colors.red[400]));
                                    }
                                  },
                                  child: Text("Create Account"),
                                ),
                              ),
                        SizedBox(height: 20),
                        Center(
                          child: GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: RichText(text: TextSpan(
                              text: "Already have an account? ",
                              style: TextStyle(color: Color(0xFF9B97CC), fontSize: 13, fontFamily: 'Poppins'),
                              children: [TextSpan(text: "Sign In", style: TextStyle(color: Color(0xFF6C63FF), fontWeight: FontWeight.w700))],
                            )),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
