import 'package:flutter/material.dart';
import '../services/mentor_service.dart';
import '../services/application_service.dart';
import '../models/mentor.dart';

class AdminAssignMentorPage extends StatefulWidget {
  final int applicationId;

  const AdminAssignMentorPage({required this.applicationId});

  @override
  State<AdminAssignMentorPage> createState() => _AdminAssignMentorPageState();
}

class _AdminAssignMentorPageState extends State<AdminAssignMentorPage> {
  List<Mentor> mentors = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadMentors();
  }

  Future loadMentors() async {
    mentors = await MentorService().getMentors();
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF8F7FF),
      appBar: AppBar(
        title: Text("Assign Mentor"),
        flexibleSpace: Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF6C63FF), Color(0xFF9C95FF)]))),
      ),
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF6C63FF)))
          : ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: mentors.length,
              itemBuilder: (_, i) {
                final m = mentors[i];
                return Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Color(0xFFEEECFF)),
                    ),
                    child: ListTile(
                      contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      leading: Container(
                        width: 46, height: 46,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [Color(0xFF26C6A2), Color(0xFF43E8C0)]),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Center(child: Text(
                          m.name.isNotEmpty ? m.name[0].toUpperCase() : '?',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                        )),
                      ),
                      title: Text(m.name, style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF1A1744))),
                      subtitle: Text(m.email, style: TextStyle(color: Color(0xFF9B97CC), fontSize: 12)),
                      trailing: ElevatedButton(
                        child: Text("Assign"),
                        onPressed: () async {
                          await ApplicationService().assignMentor(widget.applicationId, m.id);
                          Navigator.pop(context);
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
