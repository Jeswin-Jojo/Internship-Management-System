import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;

import '../models/internship_application.dart';
import '../utils/constants.dart';
import '../utils/session_manager.dart';

class ApplicationService {
  /// Headers for JSON APIs
  Future<Map<String, String>> _jsonHeaders() async {
    final token = await SessionManager.getToken();
    return {
      "Content-Type": "application/json",
      "Authorization": "Bearer $token",
    };
  }

  /// ================================
  /// APPLY WITH CV (WEB + MOBILE SAFE)
  /// ================================
  Future<String?> applyWithFile(
    int roleId,
    Uint8List bytes,
    String fileName,
  ) async {
    final token = await SessionManager.getToken();
    final userId = await SessionManager.getUserId();

    final uri = Uri.parse('${Constants.baseUrl}/Applications');
    final request = http.MultipartRequest('POST', uri);

    // Auth header
    request.headers['Authorization'] = 'Bearer $token';

    // Fields
    request.fields['userId'] = userId.toString();
    request.fields['internshipRoleId'] = roleId.toString();

    // File upload using bytes (WEB SAFE)
    request.files.add(
      http.MultipartFile.fromBytes(
        'cvFile',
        bytes,
        filename: fileName,
      ),
    );

    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode == 200 || response.statusCode == 201) {
      return null; // success
    }

    try {
      final data = jsonDecode(response.body);
      return data is String
          ? data
          : (data['message'] ?? 'Failed to apply');
    } catch (_) {
      return 'Failed to apply (${response.statusCode})';
    }
  }

  /// ======================
  /// GET ALL APPLICATIONS
  /// ======================
  Future<List<InternshipApplication>> getApplications() async {
    final headers = await _jsonHeaders();

    final response = await http.get(
      Uri.parse('${Constants.baseUrl}/Applications'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      List list = jsonDecode(response.body);
      return list.map((e) => InternshipApplication.fromJson(e)).toList();
    }

    return [];
  }

  /// ======================
  /// GET MY APPLICATIONS
  /// ======================
  Future<List<InternshipApplication>> getMyApplications() async {
    final headers = await _jsonHeaders();
    final userId = await SessionManager.getUserId();

    final response = await http.get(
      Uri.parse('${Constants.baseUrl}/Applications/user/$userId'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      List list = jsonDecode(response.body);
      return list.map((e) => InternshipApplication.fromJson(e)).toList();
    }

    return [];
  }

  /// ======================
  /// GET CV URL
  /// ======================
  String getCvUrl(int applicationId) {
    return '${Constants.baseUrl}/Applications/$applicationId/cv';
  }

  /// ======================
  /// ACCEPT APPLICATION
  /// ======================
  Future<bool> accept(int applicationId) async {
    final headers = await _jsonHeaders();

    final response = await http.put(
      Uri.parse('${Constants.baseUrl}/Applications/accept/$applicationId'),
      headers: headers,
    );

    return response.statusCode == 200;
  }

  /// ======================
  /// REJECT APPLICATION
  /// ======================
  Future<bool> reject(int applicationId, String reason) async {
    final headers = await _jsonHeaders();

    final response = await http.put(
      Uri.parse('${Constants.baseUrl}/Applications/reject/$applicationId'),
      headers: headers,
      body: jsonEncode({"reason": reason}),
    );

    return response.statusCode == 200;
  }

  /// ======================
  /// ASSIGN MENTOR
  /// ======================
  Future<bool> assignMentor(int applicationId, int mentorId) async {
    final headers = await _jsonHeaders();

    final response = await http.post(
      Uri.parse(
        '${Constants.baseUrl}/Assignments?applicationId=$applicationId&mentorId=$mentorId',
      ),
      headers: headers,
    );

    return response.statusCode == 200 || response.statusCode == 201;
  }
}