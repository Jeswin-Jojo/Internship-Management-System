import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/internship_role.dart';
import '../utils/constants.dart';
import '../utils/session_manager.dart';

class RoleService {
  Future<Map<String, String>> _authHeaders() async {
    final token = await SessionManager.getToken();
    return {
      "Content-Type": "application/json",
      "Authorization": "Bearer $token",
    };
  }

  Future<List<InternshipRole>> getRoles() async {
    final headers = await _authHeaders();
    final response = await http.get(
      Uri.parse('${Constants.baseUrl}/InternshipRoles'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      List data = json.decode(response.body);
      return data.map((e) => InternshipRole.fromJson(e)).toList();
    }
    return [];
  }

  Future<bool> createRole(String title, String description) async {
    final headers = await _authHeaders();
    final response = await http.post(
      Uri.parse('${Constants.baseUrl}/InternshipRoles'),
      headers: headers,
      body: json.encode({
        "title": title,
        "description": description,
        "availableSeats": 1,
      }),
    );
    return response.statusCode == 200 || response.statusCode == 201;
  }

  Future<bool> deleteRole(int id) async {
    final headers = await _authHeaders();
    final response = await http.delete(
      Uri.parse('${Constants.baseUrl}/InternshipRoles/$id'),
      headers: headers,
    );
    return response.statusCode == 200 || response.statusCode == 204;
  }

  /// Decrement available seats by 1 when a student is accepted
  Future<bool> decrementSeats(int roleId, String title, String description, int currentSeats) async {
    if (currentSeats <= 0) return false;
    final headers = await _authHeaders();
    final response = await http.put(
      Uri.parse('${Constants.baseUrl}/InternshipRoles/$roleId'),
      headers: headers,
      body: json.encode({
        "id": roleId,
        "title": title,
        "description": description,
        "availableSeats": currentSeats - 1,
      }),
    );
    return response.statusCode == 200 || response.statusCode == 204;
  }
}
