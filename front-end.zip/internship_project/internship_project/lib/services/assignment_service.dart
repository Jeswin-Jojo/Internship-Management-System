import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/internship_assignment.dart';
import '../utils/constants.dart';
import '../utils/session_manager.dart';

class AssignmentService {
  Future<Map<String, String>> _authHeaders() async {
    final token = await SessionManager.getToken();
    return {
      "Content-Type": "application/json",
      "Authorization": "Bearer $token",
    };
  }

  Future<List<InternshipAssignment>> getAssignments() async {
    final headers = await _authHeaders();
    final response = await http.get(
      Uri.parse('${Constants.baseUrl}/Assignments'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      List data = json.decode(response.body);
      return data.map((e) => InternshipAssignment.fromJson(e)).toList();
    }
    return [];
  }

  /// Get the assignment for a specific student by their userId
  Future<InternshipAssignment?> getMyAssignment(int userId) async {
    final all = await getAssignments();
    // Find assignment where the application belongs to this user
    try {
      return all.firstWhere((a) => a.applicationUserId == userId);
    } catch (_) {
      return null;
    }
  }

  Future<bool> assign(int applicationId, int mentorId) async {
    final headers = await _authHeaders();
    final response = await http.post(
      Uri.parse(
          '${Constants.baseUrl}/Assignments?applicationId=$applicationId&mentorId=$mentorId'),
      headers: headers,
    );
    return response.statusCode == 200 || response.statusCode == 201;
  }
}
