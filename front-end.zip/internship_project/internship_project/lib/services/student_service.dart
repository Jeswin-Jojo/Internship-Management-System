import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/constants.dart';
import '../utils/session_manager.dart';

class StudentService {
  Future<List<dynamic>> getAvailableRoles() async {
    final token = await SessionManager.getToken();
    final url = Uri.parse("${Constants.baseUrl}/roles");

    final response = await http.get(
      url,
      headers: {"Authorization": "Bearer $token"},
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return [];
  }

  Future<bool> applyForInternship(int roleId) async {
    final token = await SessionManager.getToken();
    final url = Uri.parse("${Constants.baseUrl}/applications");

    final response = await http.post(
      url,
      headers: {"Authorization": "Bearer $token", "Content-Type": "application/json"},
      body: jsonEncode({"roleId": roleId}),
    );

    return response.statusCode == 200;
  }
}