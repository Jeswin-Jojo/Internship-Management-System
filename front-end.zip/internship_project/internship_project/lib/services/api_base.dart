import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/constants.dart';
import '../utils/session_manager.dart';

class ApiBase {
  static Future<http.Response> get(String endpoint) async {
    final token = await SessionManager.getToken();
    return http.get(
      Uri.parse('${Constants.baseUrl}/$endpoint'),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token",
      },
    );
  }

  static Future<http.Response> post(String endpoint, Map<String, dynamic> body) async {
    final token = await SessionManager.getToken();
    return http.post(
      Uri.parse('${Constants.baseUrl}/$endpoint'),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token",
      },
      body: json.encode(body),
    );
  }

  static Future<http.Response> put(String endpoint, Map<String, dynamic> body) async {
    final token = await SessionManager.getToken();
    return http.put(
      Uri.parse('${Constants.baseUrl}/$endpoint'),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token",
      },
      body: json.encode(body),
    );
  }

  static Future<http.Response> delete(String endpoint) async {
    final token = await SessionManager.getToken();
    return http.delete(
      Uri.parse('${Constants.baseUrl}/$endpoint'),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token",
      },
    );
  }
}
