import 'dart:convert';
import '../models/user.dart';
import 'api_base.dart';

class UserService {
  Future<User?> getProfile() async {
    final res = await ApiBase.get("Users/me");

    if (res.statusCode == 200) {
      return User.fromJson(jsonDecode(res.body));
    }
    return null;
  }
}
