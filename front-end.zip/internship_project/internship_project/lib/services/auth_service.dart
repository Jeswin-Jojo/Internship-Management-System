import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/session_manager.dart';
import '../models/login_request.dart';
import '../models/register_request.dart';
import '../utils/constants.dart';
import 'user_service.dart';

class AuthService {
  Future<bool> login(LoginRequest request) async {
    final response = await http.post(
      Uri.parse('${Constants.baseUrl}/Auth/login'),
      headers: {"Content-Type": "application/json"},
      body: json.encode(request.toJson()),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      await SessionManager.saveToken(data['token']);
      await SessionManager.saveRole(data['role']);

      // Extract userId from JWT claims
      final userId = _getUserIdFromToken(data['token']);
      if (userId != null) {
        await SessionManager.saveUserId(userId);
      }

      // Try 1: extract name directly from JWT claims (fastest, no extra API call)
      final nameFromToken = _getNameFromToken(data['token']);
      if (nameFromToken != null && nameFromToken.isNotEmpty) {
        await SessionManager.saveName(nameFromToken);
      } else {
        // Try 2: fetch name from profile API as fallback
        try {
          final user = await UserService().getProfile();
          if (user != null && user.name.isNotEmpty) {
            await SessionManager.saveName(user.name);
          }
        } catch (_) {}
      }

      return true;
    }
    return false;
  }

  Future<bool> register(RegisterRequest request) async {
    final response = await http.post(
      Uri.parse('${Constants.baseUrl}/Auth/register'),
      headers: {"Content-Type": "application/json"},
      body: json.encode(request.toJson()),
    );
    return response.statusCode == 200 || response.statusCode == 201;
  }

  /// Extract name from JWT payload claims
  String? _getNameFromToken(String token) {
    try {
      final map = _decodeJwtPayload(token);
      if (map == null) return null;
      // ASP.NET Core uses several claim keys for the display name
      return (map['name'] ??
              map['unique_name'] ??
              map['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'] ??
              map['given_name'])
          ?.toString();
    } catch (_) {
      return null;
    }
  }

  /// Extract userId from JWT payload claims
  int? _getUserIdFromToken(String token) {
    try {
      final map = _decodeJwtPayload(token);
      if (map == null) return null;
      return int.tryParse(
        (map['sub'] ??
                map['nameid'] ??
                map['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'] ??
                '')
            .toString(),
      );
    } catch (_) {
      return null;
    }
  }

  Map<String, dynamic>? _decodeJwtPayload(String token) {
    try {
      final parts = token.split('.');
      if (parts.length != 3) return null;
      String payload = parts[1];
      while (payload.length % 4 != 0) {
        payload += '=';
      }
      final decoded = utf8.decode(base64Url.decode(payload));
      return json.decode(decoded) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }
}
