import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/mentor.dart';
import '../utils/constants.dart';
import '../utils/session_manager.dart';

class MentorService {
  Future<Map<String, String>> _authHeaders() async {
    final token = await SessionManager.getToken();
    return {
      "Content-Type": "application/json",
      "Authorization": "Bearer $token",
    };
  }

  Future<List<Mentor>> getMentors() async {
    final headers = await _authHeaders();
    final response = await http.get(
      Uri.parse('${Constants.baseUrl}/Mentors'),
      headers: headers,
    );

    if (response.statusCode == 200) {
      List list = json.decode(response.body);
      return list.map((e) => Mentor.fromJson(e)).toList();
    }
    return [];
  }

  Future<bool> createMentor(String name, String email, [String phone = '']) async {
    final headers = await _authHeaders();
    final response = await http.post(
      Uri.parse('${Constants.baseUrl}/Mentors'),
      headers: headers,
      body: json.encode({
        "name": name,
        "email": email,
        "phone": phone,
      }),
    );
    return response.statusCode == 200 || response.statusCode == 201;
  }

  Future<bool> deleteMentor(int id) async {
    final headers = await _authHeaders();
    final response = await http.delete(
      Uri.parse('${Constants.baseUrl}/Mentors/$id'),
      headers: headers,
    );
    return response.statusCode == 200 || response.statusCode == 204;
  }
}
