class ApiConstants {
  static const String baseUrl = "http://localhost:5000/api";

  static const String login = "$baseUrl/auth/login";
  static const String register = "$baseUrl/auth/register";

  static const String roles = "$baseUrl/internshiproles";
  static const String mentors = "$baseUrl/mentors";
  static const String applications = "$baseUrl/internshipapplications";
  static const String assignments = "$baseUrl/internshipassignments";
}