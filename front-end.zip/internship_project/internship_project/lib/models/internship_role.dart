class InternshipRole {
  final int id;
  final String title;
  final String description;
  final int availableSeats;

  InternshipRole({
    required this.id,
    required this.title,
    required this.description,
    required this.availableSeats,
  });

  factory InternshipRole.fromJson(Map<String, dynamic> json) {
    return InternshipRole(
      id: json['id'] ?? json['Id'] ?? 0,
      title: json['title'] ?? json['Title'] ?? '',
      description: json['description'] ?? json['Description'] ?? '',
      availableSeats: json['availableSeats'] ?? json['AvailableSeats'] ?? 0,
    );
  }
}
