class Mentor {
  final int id;
  final String name;
  final String email;
  final String phone;

  Mentor({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
  });

  factory Mentor.fromJson(Map<String, dynamic> json) {
    return Mentor(
      id: json['id'] ?? json['Id'] ?? 0,
      name: json['name'] ?? json['Name'] ?? '',
      email: json['email'] ?? json['Email'] ?? '',
      phone: json['phone'] ?? json['Phone'] ?? '',
    );
  }
}
