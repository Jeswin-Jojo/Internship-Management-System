class InternshipApplication {
  final int id;
  final int userId;
  final int roleId;
  final String userName;
  final String roleTitle;
  final String status;
  final String cvLink;
  final String? rejectionReason;

  InternshipApplication({
    required this.id,
    required this.userId,
    required this.roleId,
    required this.userName,
    required this.roleTitle,
    required this.status,
    required this.cvLink,
    this.rejectionReason,
  });

  factory InternshipApplication.fromJson(Map<String, dynamic> json) {
    // Backend may return nested objects or flat fields — handle both cases
    final user = json['user'] ?? json['User'];
    final role = json['internshipRole'] ?? json['InternshipRole'] ?? json['role'] ?? json['Role'];

    // Resolve userName: prefer nested user object, fallback to flat fields
    final userName = (user != null && (user['name'] ?? user['Name'] ?? '').toString().isNotEmpty)
        ? (user['name'] ?? user['Name'] ?? '')
        : (json['userName'] ?? json['UserName'] ?? json['studentName'] ?? '');

    // Resolve roleTitle: prefer nested role object, fallback to flat fields
    final roleTitle = (role != null && (role['title'] ?? role['Title'] ?? '').toString().isNotEmpty)
        ? (role['title'] ?? role['Title'] ?? '')
        : (json['roleTitle'] ?? json['RoleTitle'] ?? json['internshipRoleTitle'] ?? '');

    return InternshipApplication(
      id: json['id'] ?? json['Id'] ?? 0,
      userId: json['userId'] ?? json['UserId'] ?? 0,
      roleId: json['roleId'] ?? json['RoleId'] ?? 0,
      userName: userName.toString(),
      roleTitle: roleTitle.toString(),
      status: json['status'] ?? json['Status'] ?? 'Pending',
      cvLink: json['cvLink'] ?? json['CvLink'] ?? '',
      rejectionReason: json['rejectionReason'] ?? json['RejectionReason'],
    );
  }
}
