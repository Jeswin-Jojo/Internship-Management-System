class InternshipAssignment {
  final int id;
  final int applicationId;
  final int applicationUserId; // userId from the nested application object
  final int mentorId;
  final String mentorName;
  final String mentorEmail;
  final String mentorPhone;
  final String roleTitle;

  InternshipAssignment({
    required this.id,
    required this.applicationId,
    required this.applicationUserId,
    required this.mentorId,
    required this.mentorName,
    required this.mentorEmail,
    required this.mentorPhone,
    required this.roleTitle,
  });

  factory InternshipAssignment.fromJson(Map<String, dynamic> json) {
    final mentor = json['mentor'];
    final application = json['application'];
    final role = application != null ? application['internshipRole'] : null;

    return InternshipAssignment(
      id: json['id'] ?? 0,
      applicationId: json['applicationId'] ?? 0,
      applicationUserId: application != null ? (application['userId'] ?? 0) : 0,
      mentorId: json['mentorId'] ?? 0,
      mentorName: mentor != null ? (mentor['name'] ?? '') : '',
      mentorEmail: mentor != null ? (mentor['email'] ?? '') : '',
      mentorPhone: mentor != null ? (mentor['phone'] ?? '') : '',
      roleTitle: role != null ? (role['title'] ?? '') : '',
    );
  }
}
