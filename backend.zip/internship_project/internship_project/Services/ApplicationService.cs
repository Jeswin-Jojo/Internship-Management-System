﻿using internship_project.Data;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Services;

public class ApplicationService
{
    private readonly AppDbContext _context;

    public ApplicationService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<InternshipApplication> Apply(InternshipApplication app)
    {
        _context.InternshipApplications.Add(app);
        await _context.SaveChangesAsync();
        return app;
    }

    public async Task<List<InternshipApplication>> GetAll()
    {
        return await _context.InternshipApplications
            .Include(x => x.User)
            .Include(x => x.InternshipRole)
            .ToListAsync();
    }
}
