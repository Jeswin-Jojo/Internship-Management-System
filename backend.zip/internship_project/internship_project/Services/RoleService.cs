﻿using internship_project.Data;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Services;

public class RoleService
{
    private readonly AppDbContext _context;

    public RoleService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<InternshipRole> Create(InternshipRole role)
    {
        _context.InternshipRoles.Add(role);
        await _context.SaveChangesAsync();
        return role;
    }

    public async Task<List<InternshipRole>> GetAll()
    {
        return await _context.InternshipRoles.ToListAsync();
    }
}