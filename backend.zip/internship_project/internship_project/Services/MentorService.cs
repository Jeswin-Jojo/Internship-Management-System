﻿namespace internship_project.Services
{
    public class MentorService
    {
    }
}
