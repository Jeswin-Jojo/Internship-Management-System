﻿using internship_project.Data;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Services;

public class AssignmentService
{
    private readonly AppDbContext _context;

    public AssignmentService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<InternshipAssignment> Assign(int appId, int mentorId)
    {
        var assign = new InternshipAssignment
        {
            ApplicationId = appId,
            MentorId = mentorId
        };

        _context.InternshipAssignments.Add(assign);
        await _context.SaveChangesAsync();
        return assign;
    }

    public async Task<List<InternshipAssignment>> GetAll()
    {
        return await _context.InternshipAssignments
            .Include(x => x.Application)
            .Include(x => x.Mentor)
            .ToListAsync();
    }
}