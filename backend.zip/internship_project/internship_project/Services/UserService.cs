﻿using internship_project.Data;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Services;

public class UserService
{
    private readonly AppDbContext _context;

    public UserService(AppDbContext context)
    {
        _context = context;
    }

    public async Task<User> Create(User user)
    {
        _context.Users.Add(user);
        await _context.SaveChangesAsync();
        return user;
    }

    public async Task<List<User>> GetAll()
    {
        return await _context.Users.ToListAsync();
    }
}