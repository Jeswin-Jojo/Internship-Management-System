﻿using Microsoft.AspNetCore.Mvc;
using internship_project.Data;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MentorsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public MentorsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Mentors
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Mentor>>> GetMentors()
        {
            return await _context.Mentors.ToListAsync();
        }

        // POST: api/Mentors
        [HttpPost]
        public async Task<ActionResult<Mentor>> CreateMentor(Mentor mentor)
        {
            _context.Mentors.Add(mentor);
            await _context.SaveChangesAsync();
            return Ok(mentor);
        }

        // PUT: api/Mentors/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateMentor(int id, Mentor mentor)
        {
            var existing = await _context.Mentors.FindAsync(id);

            if (existing == null)
                return NotFound();

            existing.Name = mentor.Name;
            existing.Email = mentor.Email;

            await _context.SaveChangesAsync();
            return Ok(existing);
        }

        // DELETE: api/Mentors/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMentor(int id)
        {
            var mentor = await _context.Mentors.FindAsync(id);

            if (mentor == null)
                return NotFound();

            _context.Mentors.Remove(mentor);
            await _context.SaveChangesAsync();

            return Ok("Deleted successfully");
        }
    }
}