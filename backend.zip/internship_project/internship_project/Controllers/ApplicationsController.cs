﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using internship_project.Data;
using internship_project.DTOs;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ApplicationsController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IWebHostEnvironment _env;

    // Allowed CV file types
    private static readonly string[] AllowedExtensions = [".pdf", ".doc", ".docx"];
    private const long MaxFileSizeBytes = 5 * 1024 * 1024; // 5 MB

    public ApplicationsController(AppDbContext context, IWebHostEnvironment env)
    {
        _context = context;
        _env = env;
    }

    // ─────────────────────────────────────────────
    // APPLY FOR INTERNSHIP (Student) — multipart/form-data
    // POST /api/applications
    // Form fields: UserId, InternshipRoleId, CvFile (file)
    // ─────────────────────────────────────────────
    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Apply([FromForm] int userId,
                                           [FromForm] int internshipRoleId,
                                           IFormFile? cvFile)
    {
        // Validate CV file presence
        if (cvFile == null || cvFile.Length == 0)
            return BadRequest("A CV file is required.");

        // Validate file size
        if (cvFile.Length > MaxFileSizeBytes)
            return BadRequest("CV file must be smaller than 5 MB.");

        // Validate file extension
        var ext = Path.GetExtension(cvFile.FileName).ToLowerInvariant();
        if (!AllowedExtensions.Contains(ext))
            return BadRequest("CV must be a PDF, DOC, or DOCX file.");

        // Check user and role exist
        var userExists = await _context.Users.AnyAsync(u => u.Id == userId);
        if (!userExists) return BadRequest("User not found.");

        var roleExists = await _context.InternshipRoles.AnyAsync(r => r.Id == internshipRoleId);
        if (!roleExists) return BadRequest("Internship role not found.");

        // Prevent duplicate applications
        var alreadyApplied = await _context.InternshipApplications
            .AnyAsync(a => a.UserId == userId && a.InternshipRoleId == internshipRoleId);
        if (alreadyApplied)
            return Conflict("You have already applied for this role.");

        // Save file to wwwroot/cvs/
        var cvFolder = Path.Combine(_env.WebRootPath, "cvs");
        Directory.CreateDirectory(cvFolder);

        // Use a unique file name to prevent collisions/overwrites
        var fileName = $"cv_{userId}_{internshipRoleId}_{Guid.NewGuid()}{ext}";
        var filePath = Path.Combine(cvFolder, fileName);

        using (var stream = new FileStream(filePath, FileMode.Create))
        {
            await cvFile.CopyToAsync(stream);
        }

        var app = new InternshipApplication
        {
            UserId = userId,
            InternshipRoleId = internshipRoleId,
            CvFileName = fileName,
            Status = "Pending",
            AppliedAt = DateTime.UtcNow
        };

        _context.InternshipApplications.Add(app);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            app.Id,
            app.UserId,
            app.InternshipRoleId,
            app.Status,
            app.AppliedAt,
            CvUrl = $"/cvs/{fileName}"
        });
    }

    // ─────────────────────────────────────────────
    // GET ALL APPLICATIONS (Admin only)
    // GET /api/applications
    // ─────────────────────────────────────────────
    [HttpGet]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> GetAll()
    {
        var apps = await _context.InternshipApplications
            .Include(x => x.User)
            .Include(x => x.InternshipRole)
            .Select(x => new
            {
                x.Id,
                x.Status,
                x.RejectionReason,
                x.AppliedAt,
                CvUrl = x.CvFileName != null ? $"/cvs/{x.CvFileName}" : null,
                User = new { x.User!.Id, x.User.Name, x.User.Email },
                Role = new { x.InternshipRole!.Id, x.InternshipRole.Title }
            })
            .ToListAsync();

        return Ok(apps);
    }

    // ─────────────────────────────────────────────
    // DOWNLOAD / VIEW CV (Admin only)
    // GET /api/applications/{id}/cv
    // ─────────────────────────────────────────────
    [HttpGet("{id}/cv")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DownloadCv(int id)
    {
        var app = await _context.InternshipApplications.FindAsync(id);
        if (app == null) return NotFound("Application not found.");
        if (string.IsNullOrEmpty(app.CvFileName)) return NotFound("No CV on file for this application.");

        var filePath = Path.Combine(_env.WebRootPath, "cvs", app.CvFileName);
        if (!System.IO.File.Exists(filePath)) return NotFound("CV file missing from server.");

        var ext = Path.GetExtension(app.CvFileName).ToLowerInvariant();
        var contentType = ext switch
        {
            ".pdf" => "application/pdf",
            ".doc" => "application/msword",
            ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            _ => "application/octet-stream"
        };

        var bytes = await System.IO.File.ReadAllBytesAsync(filePath);
        return File(bytes, contentType, app.CvFileName);
    }

    // ─────────────────────────────────────────────
    // ACCEPT APPLICATION (Admin only)
    // PUT /api/applications/accept/{id}
    // ─────────────────────────────────────────────
    [HttpPut("accept/{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Accept(int id)
    {
        var app = await _context.InternshipApplications.FindAsync(id);
        if (app == null) return NotFound();

        app.Status = "Accepted";
        app.RejectionReason = null;

        await _context.SaveChangesAsync();
        return Ok(app);
    }

    // ─────────────────────────────────────────────
    // REJECT APPLICATION (Admin only)
    // PUT /api/applications/reject/{id}
    // Body: { "reason": "..." }
    // ─────────────────────────────────────────────
    [HttpPut("reject/{id}")]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Reject(int id, [FromBody] RejectDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Reason))
            return BadRequest("A rejection reason is required.");

        var app = await _context.InternshipApplications.FindAsync(id);
        if (app == null) return NotFound();

        app.Status = "Rejected";
        app.RejectionReason = dto.Reason;

        await _context.SaveChangesAsync();
        return Ok(app);
    }

    // ─────────────────────────────────────────────
    // GET APPLICATIONS BY USER (Student sees own apps)
    // GET /api/applications/user/{userId}
    // ─────────────────────────────────────────────
    [HttpGet("user/{userId}")]
    [Authorize]
    public async Task<IActionResult> GetByUser(int userId)
    {
        var apps = await _context.InternshipApplications
            .Where(x => x.UserId == userId)
            .Include(x => x.InternshipRole)
            .Select(x => new
            {
                x.Id,
                x.Status,
                x.RejectionReason,
                x.AppliedAt,
                HasCv = x.CvFileName != null,
                Role = new { x.InternshipRole!.Id, x.InternshipRole.Title }
            })
            .ToListAsync();

        return Ok(apps);
    }
}
