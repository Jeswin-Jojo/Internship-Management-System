﻿using Microsoft.AspNetCore.Mvc;
using internship_project.Data;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _context;

    public UsersController(AppDbContext context)
    {
        _context = context;
    }

    // GET ALL USERS (Admin)
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _context.Users.ToListAsync());
    }

    // GET USER BY ID
    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null) return NotFound();

        return Ok(user);
    }

    // UPDATE ROLE (Student → Admin)
    [HttpPut("role/{id}")]
    public async Task<IActionResult> UpdateRole(int id, string role)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null) return NotFound();

        user.Role = role;
        await _context.SaveChangesAsync();

        return Ok(user);
    }

    // DELETE USER
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null) return NotFound();

        _context.Users.Remove(user);
        await _context.SaveChangesAsync();

        return Ok("Deleted");
    }
}