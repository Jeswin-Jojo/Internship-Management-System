﻿using Microsoft.AspNetCore.Mvc;
using internship_project.Data;
using internship_project.Models;
using internship_project.DTOs;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Controllers;

[ApiController]
[Route("api/[controller]")]
public class InternshipRolesController : ControllerBase
{
    private readonly AppDbContext _context;

    public InternshipRolesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<IActionResult> Create(RoleDto dto)
    {
        var role = new InternshipRole
        {
            Title = dto.Title,
            Description = dto.Description,
            AvailableSeats = dto.AvailableSeats
        };

        _context.InternshipRoles.Add(role);
        await _context.SaveChangesAsync();
        return Ok(role);
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _context.InternshipRoles.ToListAsync());
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, RoleDto dto)
    {
        var role = await _context.InternshipRoles.FindAsync(id);
        if (role == null) return NotFound();

        role.Title = dto.Title;
        role.Description = dto.Description;
        role.AvailableSeats = dto.AvailableSeats;

        await _context.SaveChangesAsync();
        return Ok(role);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        var role = await _context.InternshipRoles.FindAsync(id);
        if (role == null) return NotFound();

        _context.InternshipRoles.Remove(role);
        await _context.SaveChangesAsync();

        return Ok("Deleted");
    }
}