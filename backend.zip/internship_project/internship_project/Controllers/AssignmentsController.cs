﻿using Microsoft.AspNetCore.Mvc;
using internship_project.Data;
using internship_project.Models;
using Microsoft.EntityFrameworkCore;

namespace internship_project.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AssignmentsController : ControllerBase
{
    private readonly AppDbContext _context;

    public AssignmentsController(AppDbContext context)
    {
        _context = context;
    }

    [HttpPost]
    public async Task<IActionResult> Assign(int applicationId, int mentorId)
    {
        var assign = new InternshipAssignment
        {
            ApplicationId = applicationId,
            MentorId = mentorId
        };

        _context.InternshipAssignments.Add(assign);
        await _context.SaveChangesAsync();

        return Ok(assign);
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _context.InternshipAssignments
            .Include(x => x.Application)
            .Include(x => x.Mentor)
            .ToListAsync());
    }
}