﻿using Microsoft.EntityFrameworkCore;
using internship_project.Models;

namespace internship_project.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<User> Users { get; set; }

        public DbSet<InternshipApplication> InternshipApplications { get; set; }

        public DbSet<InternshipAssignment> InternshipAssignments { get; set; }

        public DbSet<InternshipRole> InternshipRoles { get; set; }

        // ✅ ADD THIS (missing earlier)
        public DbSet<Mentor> Mentors { get; set; }
    }
}