﻿namespace internship_project.DTOs;

public class RejectDto
{
    public string Reason { get; set; } = "";
}
