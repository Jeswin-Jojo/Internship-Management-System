﻿namespace internship_project.DTOs;

public class RoleDto
{
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public int AvailableSeats { get; set; }
}