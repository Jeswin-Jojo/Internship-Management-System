﻿namespace internship_project.DTOs;

public class ApplyDto
{
    public int UserId { get; set; }
    public int InternshipRoleId { get; set; }
    // CV file is sent as multipart/form-data — see ApplicationsController.Apply
}
