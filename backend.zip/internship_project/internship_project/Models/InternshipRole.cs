﻿namespace internship_project.Models;

public class InternshipRole
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public int AvailableSeats { get; set; }
}