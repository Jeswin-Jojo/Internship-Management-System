﻿namespace internship_project.Models;

public class InternshipApplication
{
    public int Id { get; set; }

    public int UserId { get; set; }
    public User? User { get; set; }

    public int InternshipRoleId { get; set; }
    public InternshipRole? InternshipRole { get; set; }

    // Stores the saved file name (e.g. "cv_3_resume.pdf") — NOT a URL submitted by the student
    public string? CvFileName { get; set; }

    public string Status { get; set; } = "Pending";

    public string? RejectionReason { get; set; }

    public DateTime AppliedAt { get; set; } = DateTime.UtcNow;
}
