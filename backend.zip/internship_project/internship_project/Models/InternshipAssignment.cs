﻿namespace internship_project.Models;

public class InternshipAssignment
{
    public int Id { get; set; }

    public int ApplicationId { get; set; }
    public InternshipApplication? Application { get; set; }

    public int MentorId { get; set; }
    public Mentor? Mentor { get; set; }
}